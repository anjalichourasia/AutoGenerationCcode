# AutoGenerationOfCcode
Given an algorithm, output an auto generated C Code

* This repo consists of two folders:
  * BruteForceApproach - Using simple string matching algorithm to achieve the objectives
  * GrammarBasedApproach - Making use of Lex to tokenize and Yacc to specify the grammer to convert it to corresponding C Code and generate Abstract Syntax Tree for visualization
