# The code aims to convert a pseudo code given by the user to a working C code
* Input:
 The algorithm is given by the user in a predefined format.
* Output:
 The output will be auto-generated C code as per user requirement.
* Implementation:
 Using String Matching on the algorithm provided by the user to perform an analysis of the user’s requirement. The result from the analysis will be used to generate the required C code using Trees and Stack.
 
* Example:
  INPUT:
  a<-10
  OUTPUT:
  int a =10;
  IMPLEMENTATION:
  In this given example, the ‘<-’ is interpreted as an assignment statement and replaced with ‘=’. The data type of the  right hand side operand  is interpreted and the corresponding declaration is done.

